import { Container,Row,Col } from "react-bootstrap"

export default function Footer(){

    return(
        <div className="footer ">
  <Row>
    <Col>1 of 3</Col>
    <Col>2 of 3</Col>
    <Col>3 of 3</Col>
  </Row>
  <Row>
    <Col><p>© Copyright : SHOPCART</p></Col>
  </Row>
</div>

    )}